<template>
  <div id="app">
    <h1>index页面</h1>
    <Header/>
    <a href="page1.html">page1</a>
    <a href="page2.html">page2</a>
  </div>
</template>

<script>
import Header from '@/components/Header.vue'
export default {
  name: 'index',
  components:{
      Header
  }
}
</script>

<style>
#app {
  display: flex;
  flex-direction: column;
  align-items: center;
}
</style>
