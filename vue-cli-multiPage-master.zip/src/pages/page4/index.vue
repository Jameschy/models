<template>
  <div id="app">
    <h1>page4</h1>
    <Header/>
  </div>
</template>
<script>
    import Header from '@/components/Header.vue'

    export default {
        name: 'page4',
        components: {
            Header
        }
    }
</script>

<style>
</style>
