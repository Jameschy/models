<template>
  <div id="app">
    <Header/>
    <img alt="Vue logo" src="../../assets/logo.png">
    <HelloWorld msg="Welcome to Page1"/>

    <List/>
    <Footer/>
    <ToTop/>
  </div>
</template>

<script>
import HelloWorld from '@/components/HelloWorld'
import Header from '@/components/Header'
import Footer from '@/components/Footer'
import ToTop from '@/components/ToTop'
import List from '@/modules/List'

export default {
  name: 'page1',
  components: {
    HelloWorld,
      Header,
      Footer,
      ToTop,
      List

  }
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
