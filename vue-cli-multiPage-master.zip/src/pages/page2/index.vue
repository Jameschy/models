<template>
  <div id="app">
    <h1>page2</h1>
    <Header/>
    <Footer/>
  </div>
</template>
<script>
    import Header from '@/components/Header.vue'
    import Footer from '@/components/Footer.vue'

    export default {
        name: 'page1',
        components: {
            Header,
            Footer
        }
    }
</script>

<style>
</style>
