<template>
  <div id="app">
      <el-container>
          <el-header>
              <el-menu :default-active="activeIndex" class="el-menu-demo" mode="horizontal" @select="handleSelect">
                  <el-menu-item index="1"><a href="index.html" target="_blank">首页</a></el-menu-item>
                  <el-submenu index="2">
                      <template slot="title">手机软件</template>
                      <el-menu-item index="2-1"><a href="page1.html" target="_blank">游戏软件</a></el-menu-item>
                      <el-menu-item index="2-2"><a href="page1.html" target="_blank">资讯软件</a></el-menu-item>
                      <el-submenu index="2-3">
                          <template slot="title">安卓软件</template>
                          <el-menu-item index="2-3-1"><a href="page2.html" target="_blank">枪战</a></el-menu-item>
                          <el-menu-item index="2-3-2"><a href="page2.html" target="_blank">棋牌</a></el-menu-item>
                          <el-menu-item index="2-3-3"><a href="page2.html" target="_blank">策略</a></el-menu-item>
                      </el-submenu>
                      <el-submenu index="2-4">
                          <template slot="title">苹果软件</template>
                          <el-menu-item index="2-4-1">选项1</el-menu-item>
                          <el-menu-item index="2-4-2">选项2</el-menu-item>
                          <el-menu-item index="2-4-3">选项3</el-menu-item>
                      </el-submenu>
                  </el-submenu>
                  <el-submenu index="3">
                      <template slot="title">桌面软件</template>
                      <el-menu-item index="3-1"><a href="page3.html" target="_blank">游戏软件</a></el-menu-item>
                      <el-menu-item index="3-2"><a href="page3.html" target="_blank">资讯软件</a></el-menu-item>
                      <el-submenu index="3-3">
                          <template slot="title">安卓软件</template>
                          <el-menu-item index="3-3-1"><a href="page4.html" target="_blank">枪战</a></el-menu-item>
                          <el-menu-item index="3-3-2"><a href="page4.html" target="_blank">枪战</a></el-menu-item>
                          <el-menu-item index="3-3-3"><a href="page4.html" target="_blank">枪战</a></el-menu-item>
                      </el-submenu>
                      <el-submenu index="3-4">
                          <template slot="title">苹果软件</template>
                          <el-menu-item index="3-4-1">选项1</el-menu-item>
                          <el-menu-item index="3-4-2">选项2</el-menu-item>
                          <el-menu-item index="3-4-3">选项3</el-menu-item>
                      </el-submenu>
                  </el-submenu>
                  <el-menu-item index="4"><a href="page5.html" target="_blank">专题</a></el-menu-item>
                  <el-menu-item index="5" class="hidden-sm-only"><a href="page5.html" target="_blank">攻略</a></el-menu-item>
                  <el-menu-item index="6" class="hidden-sm-only"><a href="page5.html" target="_blank">热门</a></el-menu-item>
              </el-menu>
              <div class="line"></div>
          </el-header>
          <el-main>
            <el-row :gutter="20">
              <el-col :span="16"><div class="grid-content bg-purple">a</div></el-col>
              <el-col :span="8"><div class="grid-content bg-purple">a</div></el-col>
            </el-row>
            <el-row :gutter="20">
              <el-col :span="8"><div class="grid-content bg-purple"></div></el-col>
              <el-col :span="8"><div class="grid-content bg-purple"></div></el-col>
              <el-col :span="4"><div class="grid-content bg-purple"></div></el-col>
              <el-col :span="4"><div class="grid-content bg-purple"></div></el-col>
            </el-row>
            <el-row :gutter="20">
              <el-col :span="4"><div class="grid-content bg-purple"></div></el-col>
              <el-col :span="16"><div class="grid-content bg-purple"></div></el-col>
              <el-col :span="4"><div class="grid-content bg-purple"></div></el-col>
            </el-row>
          </el-main>
      </el-container>
  </div>
</template>
<script>
    export default {
        name: 'page5',
        components: {
        }
    }
</script>

<style>
  .el-row {
    margin-bottom: 20px;
  &:last-child {
     margin-bottom: 0;
   }
  }
  .el-col {
    border-radius: 4px;
  }
  .bg-purple-dark {
    background: #99a9bf;
  }
  .bg-purple {
    background: #d3dce6;
  }
  .bg-purple-light {
    background: #e5e9f2;
  }
  .grid-content {
    border-radius: 4px;
    min-height: 36px;
  }
  .row-bg {
    padding: 10px 0;
    background-color: #f9fafc;
  }
</style>
