<template>
    <div id="totop">
        <a href="#">{{msg}}</a>
    </div>
</template>

<script>
    export default {
        name: "ToTop",
        data(){
            return{
                msg:'回顶部'
            }
        }
    }
</script>

<style scoped>
    #totop a{
        display: inline-block;
        position: fixed;
        right: 5%;
        bottom: 5%;
        height: 55px;
        width: 55px;
        line-height: 55px;
        background-color: #42b983;
        color: #fff;
        text-decoration: none;
        font-size: 14px;
    }
</style>
