<template>
    <div id="footer1">
        <h1>{{msg}}</h1>
    </div>
</template>

<script>
    export default {
        name: 'Footer',
        data() {
            return{
                msg: '这里是底部！！！！'
            }

        }
    }
</script>

<style scoped>
#footer1{
    color: red;
    font-size: 24px;

}
</style>
