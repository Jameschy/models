<template>
    <div id="navBox">
        <el-menu :default-active="activeIndex" class="el-menu-demo" mode="horizontal" @select="handleSelect">
            <el-menu-item index="1"><a href="index.html" target="_blank">首页</a></el-menu-item>
            <el-submenu index="2">
                <template slot="title">手机软件</template>
                <el-menu-item index="2-1"><a href="page1.html" target="_blank">游戏软件</a></el-menu-item>
                <el-menu-item index="2-2"><a href="page1.html" target="_blank">资讯软件</a></el-menu-item>
                <el-submenu index="2-3">
                    <template slot="title">安卓软件</template>
                    <el-menu-item index="2-3-1"><a href="page2.html" target="_blank">枪战</a></el-menu-item>
                    <el-menu-item index="2-3-2"><a href="page2.html" target="_blank">棋牌</a></el-menu-item>
                    <el-menu-item index="2-3-3"><a href="page2.html" target="_blank">策略</a></el-menu-item>
                </el-submenu>
                <el-submenu index="2-4">
                    <template slot="title">苹果软件</template>
                    <el-menu-item index="2-4-1">选项1</el-menu-item>
                    <el-menu-item index="2-4-2">选项2</el-menu-item>
                    <el-menu-item index="2-4-3">选项3</el-menu-item>
                </el-submenu>
            </el-submenu>
            <el-submenu index="3">
                <template slot="title">桌面软件</template>
                <el-menu-item index="3-1"><a href="page3.html" target="_blank">游戏软件</a></el-menu-item>
                <el-menu-item index="3-2"><a href="page3.html" target="_blank">资讯软件</a></el-menu-item>
                <el-submenu index="3-3">
                    <template slot="title">安卓软件</template>
                    <el-menu-item index="3-3-1"><a href="page4.html" target="_blank">枪战</a></el-menu-item>
                    <el-menu-item index="3-3-2"><a href="page4.html" target="_blank">枪战</a></el-menu-item>
                    <el-menu-item index="3-3-3"><a href="page4.html" target="_blank">枪战</a></el-menu-item>
                </el-submenu>
                <el-submenu index="3-4">
                    <template slot="title">苹果软件</template>
                    <el-menu-item index="3-4-1">选项1</el-menu-item>
                    <el-menu-item index="3-4-2">选项2</el-menu-item>
                    <el-menu-item index="3-4-3">选项3</el-menu-item>
                </el-submenu>
            </el-submenu>
            <el-menu-item index="4"><a href="page5.html" target="_blank">专题</a></el-menu-item>
            <el-menu-item index="5" class="hidden-sm-only"><a href="page5.html" target="_blank">攻略</a></el-menu-item>
            <el-menu-item index="6" class="hidden-sm-only"><a href="page5.html" target="_blank">热门</a></el-menu-item>
        </el-menu>
        <div class="line"></div>
    </div>
</template>

<script>
    export default {
        data() {
            return {
                activeIndex: '1',
                activeIndex2: '1'
            };
        },

        methods: {
            handleSelect() {
                // console.log(key, keyPath);
            }
        }
    }
</script>

<style scoped>

</style>
