<template>
    <div id="listBox">
        <ul>
            <li v-for="n in 50" :key="n">
                {{ n*2 }}
            </li>
        </ul>
    </div>
</template>
<script>
    export default {
        name: "List",
        data(){

        }
    }
</script>

<style scoped>

</style>
