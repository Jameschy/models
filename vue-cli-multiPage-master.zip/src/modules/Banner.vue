<template>
    <div id="bannerBox">

    </div>
</template>

<script>
    export default {
        name: "Banner"
    }
</script>

<style scoped>

</style>
