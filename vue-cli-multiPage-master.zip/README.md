# vue-cli-multipage1

vue-cli-multipage2.0改进版 [博客](https://www.cnblogs.com/AnnieShen/p/12035023.html) [github](https://github.com/AinneShen/vue-cli-multiPage2).
